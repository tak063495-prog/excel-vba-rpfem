Attribute VB_Name = "RPX_SeepWT"
Option Explicit
' �n�����ʁi�Z�����j���̓��[�h�ƁA�ϑ����ʂ���̋��E�����̋t����B
'  ���[�h1�F���ʐ��{cos2�ƕ␳�@h = y_wt - (y_wt - y)�~sin2�Ɓ@�iu = ��w�~hw�~cos2�ƁA���|�e���V�������͐��ʐ��ɒ����j
'  ���[�h2�F�Ð����@h = y_wt
'  ���[�h3�F�Z��FEM�̖��m���E�����i�l�Z�� "?" �܂��� "?�����l"�A�ϑ��_�� P:Q�j���ϑ����ʓ_�ɍŏ����ō��킹��i����Gauss-Newton��LM�A�������R�r�A���j
' ���ʂ͐Z�����ʃV�[�g�֓����`���ŏ������߁ARPX_Water �̘A���Ɛ}�̎��R���ʕ`��͂��̂܂܎g����B
' �����W���̐�Βl�͐�����ɉe�����Ȃ��i�䂾���������j�B

Public WTN As Long, WTX() As Double, WTY() As Double
Public SUnkCount As Long, SUnkVal() As Double, SUnkReady As Boolean
Public WTInvResult As String

Private Const WT_SHEET As String = "�Z������"
Private Const WT_FIRST As Long = 7
Private Const WT_LAST As Long = 206

Private wtTest As Boolean, wtTestNx As Long, wtTestNy As Long
Private evalCount As Long

' ---------------------------------------------------------------- table
Public Function RPX_WTReadTable(ByVal ws As Worksheet, ByVal requireTwo As Boolean, ByVal colX As Long) As Long
    Dim r As Long, vx As Variant, vy As Variant, i As Long, j As Long, t As Double
    WTN = 0: ReDim WTX(0 To WT_LAST - WT_FIRST): ReDim WTY(0 To WT_LAST - WT_FIRST)
    For r = WT_FIRST To WT_LAST
        vx = ws.cells(r, colX).Value2: vy = ws.cells(r, colX + 1).Value2
        If IsError(vx) Or IsError(vy) Then err.Raise 5, "RPX_SeepWT", "INVALID_SEEP_TABLE_CELL " & r
        If Len(CStr(vx)) > 0 Or Len(CStr(vy)) > 0 Then
            WTX(WTN) = RPX_SeepNumericValue(vx, "x " & ws.cells(r, colX).Address(False, False))
            WTY(WTN) = RPX_SeepNumericValue(vy, "y " & ws.cells(r, colX + 1).Address(False, False))
            WTN = WTN + 1
        End If
    Next r
    For i = 1 To WTN - 1
        j = i
        Do While j > 0
            If WTX(j - 1) <= WTX(j) Then Exit Do
            t = WTX(j): WTX(j) = WTX(j - 1): WTX(j - 1) = t
            t = WTY(j): WTY(j) = WTY(j - 1): WTY(j - 1) = t
            j = j - 1
        Loop
    Next i
    If requireTwo Then
        If WTN < 2 Then err.Raise 5, , "�n�����ʁiM:N�j��2�_�ȏ�� (x, y) ����͂��Ă��������B"
        For i = 1 To WTN - 1
            If WTX(i) - WTX(i - 1) <= 0.000000001 Then err.Raise 5, , "�n�����ʕ\�ɓ���x�̓_������܂��ix=" & WTX(i) & "�j�B"
        Next i
    ElseIf WTN < 1 Then
        err.Raise 5, , "�ϑ��_�iP:Q�j������܂���B"
    End If
    RPX_WTReadTable = WTN
End Function

Private Function Sin2(ByVal i As Long) As Double
    Dim dx As Double, dy As Double
    dx = WTX(i + 1) - WTX(i): dy = WTY(i + 1) - WTY(i)
    Sin2 = dy * dy / (dx * dx + dy * dy)
End Function

' ���ʐ��̕W���� sin2�Ɓi��Ԃ��Ƃ̌��z�B���[���O�͒[�̒l�Ő��������A�Ƃ͒[��Ԃ̒l�j
Private Sub WTEval(ByVal x As Double, ByRef yw As Double, ByRef s2 As Double)
    Dim i As Long, t As Double
    If x <= WTX(0) Then yw = WTY(0): s2 = Sin2(0): Exit Sub
    If x >= WTX(WTN - 1) Then yw = WTY(WTN - 1): s2 = Sin2(WTN - 2): Exit Sub
    For i = 0 To WTN - 2
        If x <= WTX(i + 1) Then
            t = (x - WTX(i)) / (WTX(i + 1) - WTX(i))
            yw = WTY(i) + t * (WTY(i + 1) - WTY(i)): s2 = Sin2(i): Exit Sub
        End If
    Next i
    yw = WTY(WTN - 1): s2 = Sin2(WTN - 2)
End Sub

Public Function RPX_WTHead(ByVal x As Double, ByVal y As Double, ByVal mode As Long) As Double
    Dim yw As Double, s2 As Double
    WTEval x, yw, s2
    If mode = 2 Then RPX_WTHead = yw Else RPX_WTHead = yw - (yw - y) * s2
End Function

' SXY/STri�iRPX_SeepUI ���R�s�[�ς݁j�ɐ���������B�����i���ʂ���j�͂��̂܂܏����Au<0�̈����͘A�����iN20�j�ɏ]���B
Public Sub RPX_WTField(ByVal mode As Long)
    Dim i As Long
    ReDim SHead(0 To SN - 1): ReDim SPres(0 To SN - 1): ReDim SFlux(0 To SN - 1): ReDim SActive(0 To SN - 1)
    ReDim SBcType(0 To SN - 1): ReDim SBcVal(0 To SN - 1): ReDim SKr(0 To SM - 1)
    Call RPX_SeepCheckCancelled
    If Not RPX_SchurFinite(SGammaW) Or SGammaW <= 0# Then err.Raise 5, "RPX_SeepWT", "INVALID_WATER_UNIT_WEIGHT"
    For i = 0 To SN - 1
        If i Mod 1024 = 0 Then Call RPX_SeepCheckCancelled
        SHead(i) = RPX_WTHead(sxy(i, 0), sxy(i, 1), mode)
        SPres(i) = SGammaW * (SHead(i) - sxy(i, 1))
    Next i
    For i = 0 To SM - 1: SKr(i) = 1#: Next i
    Call RPX_SeepCheckCancelled
    SIterations = 0: SConverged = True: SLastDelta = 0#: SLastResidual = 0#: SLastFixDelta = 0#
End Sub

' ---------------------------------------------------------------- free surface elevation at x
Public Function RPX_WTSurfaceY(ByRef seg() As Double, ByVal n As Long, ByVal x As Double, ByRef found As Boolean) As Double
    Dim k As Long, lo As Double, hi As Double, y As Double, best As Double, have As Boolean, nd As Double, nearY As Double, d As Double
    nd = 1E+300
    For k = 0 To n - 1
        lo = seg(k, 0): hi = seg(k, 2)
        If lo > hi Then lo = seg(k, 2): hi = seg(k, 0)
        If hi - lo > 0.000000000001 And x >= lo - 0.000000001 And x <= hi + 0.000000001 Then
            y = seg(k, 1) + (seg(k, 3) - seg(k, 1)) * (x - seg(k, 0)) / (seg(k, 2) - seg(k, 0))
            If Not have Or y > best Then best = y: have = True
        End If
        d = Abs(seg(k, 0) - x): If d < nd Then nd = d: nearY = seg(k, 1)
        d = Abs(seg(k, 2) - x): If d < nd Then nd = d: nearY = seg(k, 3)
    Next k
    found = have
    If have Then RPX_WTSurfaceY = best Else RPX_WTSurfaceY = nearY
End Function

' ---------------------------------------------------------------- unknown boundary values
' �Z�����E�̒l�Z���iK��j�� "?" �܂��� "?���l" �̍s�����ɖ��m���Ƃ���Bkind�͐����E���ʁE����+�Z�o�ʂ̂݁B
Public Function RPX_WTScanUnknowns(ByVal ws As Worksheet, ByRef guess() As Double, ByRef labels() As String, ByRef hasGuess() As Boolean) As Long
    Dim r As Long, s As String, n As Long, k As String, initial As Double
    ReDim guess(0 To 9): ReDim labels(0 To 9): ReDim hasGuess(0 To 9)
    For r = WT_FIRST To WT_LAST
        If Len(CStr(ws.cells(r, 5).Value2)) > 0 Then
            s = Trim$(CStr(ws.cells(r, 11).Value2))
            If RPX_WTIsUnknown(s) Then
                k = Trim$(CStr(ws.cells(r, 10).Value2))
                If k <> "����" And k <> "����" And k <> "����+�Z�o��" And k <> "���ʁ{�Z�o��" Then err.Raise 5, , "���m���i?�j�͎�ʁu�����E���ʁE����+�Z�o�ʁv�����Ɏw��ł��܂��i���EID " & ws.cells(r, 5).Value2 & "�j�B"
                If n > 9 Then err.Raise 5, , "���m����10�܂łł��B"
                labels(n) = "���EID " & ws.cells(r, 5).Value2 & "�i" & k & "�j"
                s = mid$(s, 2)
                If Len(s) > 0 Then
                    If Not IsNumeric(s) Then err.Raise 5, "RPX_SeepWT", "INVALID_SEEP_INVERSE_GUESS ���EID " & ws.cells(r, 5).Value2 & " ��?�����l�͗L���Ȑ��l�Ŏw�肵�Ă��������B"
                    initial = RPX_SeepNumericValue(s, "?�����l K" & r)
                    guess(n) = initial: hasGuess(n) = True
                End If
                n = n + 1
            End If
        End If
    Next r
    RPX_WTScanUnknowns = n
End Function

Public Function RPX_WTIsUnknown(ByVal s As String) As Boolean
    s = Trim$(s)
    If Len(s) = 0 Then Exit Function
    RPX_WTIsUnknown = (Left$(s, 1) = "?" Or Left$(s, 1) = "�H")
End Function

' ---------------------------------------------------------------- small dense algebra (n <= 10)
Private Function SolveSmall(ByRef a() As Double, ByRef b() As Double, ByVal n As Long) As Boolean
    Dim i As Long, j As Long, k As Long, p As Long, t As Double, f As Double
    For k = 0 To n - 1
        p = k
        For i = k + 1 To n - 1
            If Abs(a(i, k)) > Abs(a(p, k)) Then p = i
        Next i
        If Abs(a(p, k)) < 1E-300 Then Exit Function
        If p <> k Then
            For j = 0 To n - 1: t = a(k, j): a(k, j) = a(p, j): a(p, j) = t: Next j
            t = b(k): b(k) = b(p): b(p) = t
        End If
        For i = k + 1 To n - 1
            f = a(i, k) / a(k, k)
            For j = k To n - 1: a(i, j) = a(i, j) - f * a(k, j): Next j
            b(i) = b(i) - f * b(k)
        Next i
    Next k
    For i = n - 1 To 0 Step -1
        t = b(i)
        For j = i + 1 To n - 1: t = t - a(i, j) * b(j): Next j
        b(i) = t / a(i, i)
    Next i
    SolveSmall = True
End Function

' �Ώ̍s��̌ŗL�l�iJacobi�@�j���������
Private Function SymCond(ByRef s() As Double, ByVal n As Long) As Double
    Dim a() As Double, i As Long, j As Long, k As Long, p As Long, q As Long, sweep As Long
    Dim off As Double, th As Double, c As Double, sv As Double, t As Double, aip As Double, aiq As Double, mx As Double, mn As Double
    ReDim a(0 To n - 1, 0 To n - 1)
    For i = 0 To n - 1
        For j = 0 To n - 1: a(i, j) = s(i, j): Next j
    Next i
    For sweep = 1 To 50
        off = 0#
        For p = 0 To n - 2
            For q = p + 1 To n - 1: off = off + a(p, q) * a(p, q): Next q
        Next p
        If off < 1E-30 Then Exit For
        For p = 0 To n - 2
            For q = p + 1 To n - 1
                If Abs(a(p, q)) > 1E-300 Then
                    th = (a(q, q) - a(p, p)) / (2# * a(p, q))
                    t = Sgn(th) / (Abs(th) + Sqr(th * th + 1#)): If th = 0# Then t = 1#
                    c = 1# / Sqr(t * t + 1#): sv = t * c
                    For k = 0 To n - 1
                        aip = a(k, p): aiq = a(k, q)
                        a(k, p) = c * aip - sv * aiq: a(k, q) = sv * aip + c * aiq
                    Next k
                    For k = 0 To n - 1
                        aip = a(p, k): aiq = a(q, k)
                        a(p, k) = c * aip - sv * aiq: a(q, k) = sv * aip + c * aiq
                    Next k
                End If
            Next q
        Next p
    Next sweep
    mx = Abs(a(0, 0)): mn = mx
    For i = 1 To n - 1
        If Abs(a(i, i)) > mx Then mx = Abs(a(i, i))
        If Abs(a(i, i)) < mn Then mn = Abs(a(i, i))
    Next i
    If mn <= 0# Then SymCond = 1E+300 Else SymCond = mx / mn
End Function

' ---------------------------------------------------------------- residuals
Private Sub BuildTestDam(ByVal h1 As Double)
    Dim nx As Long, ny As Long, i As Long, j As Long, e As Long, a As Long, b As Long, c As Long, d As Long
    nx = wtTestNx: ny = wtTestNy
    SN = (nx + 1) * (ny + 1): SM = 2 * nx * ny: SNMat = 1
    ReDim sxy(0 To SN - 1, 0 To 1): ReDim STri(0 To SM - 1, 0 To 2): ReDim SMat(0 To SM - 1)
    ReDim SKx(0 To 0): ReDim SKy(0 To 0): SKx(0) = 1#: SKy(0) = 1#
    ReDim SBcType(0 To SN - 1): ReDim SBcVal(0 To SN - 1)
    For j = 0 To ny
        For i = 0 To nx: sxy(j * (nx + 1) + i, 0) = 20# * i / nx: sxy(j * (nx + 1) + i, 1) = 10# * j / ny: Next i
    Next j
    e = 0
    For j = 0 To ny - 1
        For i = 0 To nx - 1
            a = j * (nx + 1) + i: b = a + 1: c = b + nx + 1: d = a + nx + 1
            STri(e, 0) = a: STri(e, 1) = b: STri(e, 2) = c: e = e + 1
            STri(e, 0) = a: STri(e, 1) = c: STri(e, 2) = d: e = e + 1
        Next i
    Next j
    For j = 0 To ny
        a = j * (nx + 1)
        If sxy(a, 1) <= h1 + 0.000000001 Then SBcType(a) = 1: SBcVal(a) = h1
        b = a + nx
        If sxy(b, 1) <= 2# + 0.000000001 Then SBcType(b) = 1: SBcVal(b) = 2# Else SBcType(b) = 2
    Next j
    RPX_SeepDefaults
End Sub

' 1��̏���́B���s�i�Œ萅���Ȃ����j�� False�B
Private Function WTResiduals(ByVal ws As Worksheet, ByRef p() As Double, ByVal n As Long, ByRef obsX() As Double, ByRef obsY() As Double, ByVal m As Long, ByRef r() As Double, ByRef cost As Double) As Boolean
    Dim i As Long, seg() As Double, ns As Long, found As Boolean
    Dim failureNumber As Long, failureSource As String, failureText As String
    Call RPX_SeepCheckCancelled
    On Error GoTo Failed
    evalCount = evalCount + 1
    For i = 0 To n - 1: SUnkVal(i) = p(i): Next i
    SUnkReady = True
    If wtTest Then BuildTestDam p(0) Else RPX_SeepBuildModel ws
    RPX_SeepSolve
    If Not SConverged Then Exit Function   ' #6: an unconverged forward solve is a failed evaluation
    ns = RPX_SeepFreeSurface(seg)
    If ns < 1 Then Exit Function
    cost = 0#
    For i = 0 To m - 1
        r(i) = RPX_WTSurfaceY(seg, ns, obsX(i), found) - obsY(i)
        cost = cost + r(i) * r(i)
    Next i
    If Not wtTest Then Application.StatusBar = "�t��́F����� " & evalCount & " ��ځARMS=" & Format(Sqr(cost / m), "0.000") & " m"
    DoEvents
    Call RPX_SeepCheckCancelled
    WTResiduals = True
    Exit Function
Failed:
    failureNumber = err.number: failureSource = err.source: failureText = err.description
    If failureNumber = 18 Or XCancel Then err.Raise failureNumber, failureSource, failureText
    err.Clear
End Function

' LM�@�B���ʂ� p�A�߂�l�͐������B
Private Function Invert(ByVal ws As Worksheet, ByRef p() As Double, ByVal n As Long, ByRef labels() As String, ByRef obsX() As Double, ByRef obsY() As Double, ByVal m As Long, _
                        ByVal lo As Double, ByVal hi As Double, ByVal maxEval As Long, ByRef rms As Double, ByRef warnText As String) As Boolean
    Dim r() As Double, rq() As Double, j() As Double, a() As Double, g() As Double, stp() As Double, q() As Double, lam As Double
    Dim b() As Double, cost As Double, costQ As Double, i As Long, k As Long, l As Long, d As Double, cond As Double, colNorm As Double, smax As Double, iter As Long, ok As Boolean
    ReDim r(0 To m - 1): ReDim rq(0 To m - 1): ReDim j(0 To m - 1, 0 To n - 1): ReDim a(0 To n - 1, 0 To n - 1)
    ReDim g(0 To n - 1): ReDim stp(0 To n - 1): ReDim q(0 To n - 1)
    Call RPX_SeepCheckCancelled
    evalCount = 0
    If Not WTResiduals(ws, p, n, obsX, obsY, m, r, cost) Then err.Raise 5, , "�t��́F�����l�ŐZ����͂��ł��܂���i�����������u?�l�v�Ŏw�肵�Ă��������j�B"
    lam = 0.001
    Do While evalCount + n + 1 <= maxEval
        Call RPX_SeepCheckCancelled
        iter = iter + 1
        For k = 0 To n - 1
            Call RPX_SeepCheckCancelled
            For i = 0 To n - 1: q(i) = p(i): Next i
            d = 0.001 * Abs(p(k)): If d < 0.01 Then d = 0.01
            If q(k) + d > hi Then d = -d
            q(k) = q(k) + d
            If Not WTResiduals(ws, q, n, obsX, obsY, m, rq, costQ) Then err.Raise 5, , "�t��́F�����v�Z���ɐZ����͂����s���܂����B"
            For i = 0 To m - 1: j(i, k) = (rq(i) - r(i)) / d: Next i
        Next k
        For k = 0 To n - 1
            g(k) = 0#
            For i = 0 To m - 1: g(k) = g(k) + j(i, k) * r(i): Next i
            For l = 0 To n - 1
                a(k, l) = 0#
                For i = 0 To m - 1: a(k, l) = a(k, l) + j(i, k) * j(i, l): Next i
            Next l
        Next k
        cond = SymCond(a, n)
        ok = False
        Do While evalCount < maxEval
            Call RPX_SeepCheckCancelled
            ReDim b(0 To n - 1, 0 To n - 1)
            For k = 0 To n - 1
                For l = 0 To n - 1: b(k, l) = a(k, l): Next l
                b(k, k) = a(k, k) * (1# + lam) + 0.000000000001
                stp(k) = -g(k)
            Next k
            If Not SolveSmall(b, stp, n) Then
                lam = lam * 10#
                GoTo RetryLam
            End If
            smax = 0#
            For k = 0 To n - 1
                q(k) = p(k) + stp(k)
                If q(k) < lo Then q(k) = lo
                If q(k) > hi Then q(k) = hi
                If Abs(q(k) - p(k)) > smax Then smax = Abs(q(k) - p(k))
            Next k
            If WTResiduals(ws, q, n, obsX, obsY, m, rq, costQ) Then
                If costQ < cost Then
                    For k = 0 To n - 1: p(k) = q(k): Next k
                    For i = 0 To m - 1: r(i) = rq(i): Next i
                    cost = costQ: lam = lam / 10#
                    If lam < 0.0000001 Then lam = 0.0000001
                    ok = True: Exit Do
                End If
            End If
            lam = lam * 10#
RetryLam:
            If lam > 10000000000# Then Exit Do
        Loop
        If Not ok Or smax < 0.0001 Then Exit Do
    Loop
    Call RPX_SeepCheckCancelled
    rms = Sqr(cost / m)
    warnText = ""
    If m < 2 * n + 1 Then warnText = warnText & "�ϑ��_�����Ȃ��i" & m & "�_�^���m��" & n & "�j�B"
    If cond > 100000000# Then warnText = warnText & "�������iJ^TJ�̏����� " & Format(cond, "0.0E+00") & "�j�F���m���ǂ�������ʂł��܂���B"
    For k = 0 To n - 1
        colNorm = 0#
        For i = 0 To m - 1: colNorm = colNorm + j(i, k) * j(i, k): Next i
        colNorm = Sqr(colNorm / m)
        If colNorm < 0.01 Then warnText = warnText & labels(k) & "�͊��x���������i1 m�̕ω��Ő���RMS " & Format(colNorm * 100#, "0.00") & " cm�j�B"
    Next k
    If evalCount >= maxEval Then warnText = warnText & "�����p�̏���͗\�Z�i" & maxEval & "��j�ɒB���܂����B"
    Invert = True
End Function

Private Function obsMax(ByRef v() As Double, ByVal m As Long) As Double
    Dim i As Long
    obsMax = v(0)
    For i = 1 To m - 1
        If v(i) > obsMax Then obsMax = v(i)
    Next i
End Function

Public Function RPX_WTMinimumEvaluations(ByVal unknowns As Long) As Long
    If unknowns < 1 Or unknowns > 10 Then err.Raise 5, "RPX_SeepWT", "INVALID_SEEP_UNKNOWN_COUNT"
    RPX_WTMinimumEvaluations = 3 * (unknowns + 1)
End Function

' ---------------------------------------------------------------- mode 3 entry (called by RPX_SeepRun after mesh generation)
Public Sub RPX_WTInverse(ByVal ws As Worksheet, ByVal maxEval As Long)
    Dim guess() As Double, labels() As String, hasGuess() As Boolean, n As Long, m As Long, i As Long, p() As Double
    Dim obsX() As Double, obsY() As Double, lo As Double, hi As Double, rms As Double, warnText As String, ymax As Double, ymin As Double, txt As String
    Dim res As Worksheet
    Call RPX_SeepCheckCancelled
    wtTest = False
    n = RPX_WTScanUnknowns(ws, guess, labels, hasGuess)
    If n = 0 Then err.Raise 5, , "���肷�鋫�E�̒l�Ɂu?�v������܂���B"
    m = RPX_WTReadTable(ws, False, 16)
    ReDim obsX(0 To m - 1): ReDim obsY(0 To m - 1)
    For i = 0 To m - 1: obsX(i) = WTX(i): obsY(i) = WTY(i): Next i
    ymin = RXY(0, 1): ymax = ymin
    For i = 1 To rn - 1
        If RXY(i, 1) < ymin Then ymin = RXY(i, 1)
        If RXY(i, 1) > ymax Then ymax = RXY(i, 1)
    Next i
    lo = ymin: hi = ymax + (ymax - ymin)
    ReDim p(0 To n - 1): ReDim SUnkVal(0 To n - 1): SUnkCount = n
    For i = 0 To n - 1
        If hasGuess(i) Then
            p(i) = guess(i)
        Else
            p(i) = obsMax(obsY, m)
        End If
    Next i
    If maxEval < RPX_WTMinimumEvaluations(n) Then err.Raise 5, "RPX_SeepWT", "INVALID_SEEP_INVERSE_MAX �Œ�" & RPX_WTMinimumEvaluations(n) & "�񂪕K�v�ł��B"
    ' Reserve and count the final accepted-state forward solve within the entered limit.
    Invert ws, p, n, labels, obsX, obsY, m, lo, hi, maxEval - 1, rms, warnText
    For i = 0 To n - 1: SUnkVal(i) = p(i): Next i
    Call RPX_SeepCheckCancelled
    evalCount = evalCount + 1
    RPX_SeepBuildModel ws: RPX_SeepSolve
    Call RPX_SeepCheckCancelled
    RPX_SeepWriteResults
    Set res = RPX_Sheet("�Z������")
    res.Range("J10").Value2 = "���[�h": res.Range("K10").Value2 = "3�F���m���E�����̋t����"
    res.Range("J11").Value2 = "����RMS [m]": res.Range("K11").Value2 = rms
    res.Range("J12").Value2 = "����͉�": res.Range("K12").Value2 = evalCount
    res.Range("J13").Value2 = "�ϑ��_��": res.Range("K13").Value2 = m
    res.Range("J14").Value2 = "����": res.Range("K14").Value2 = IIf(Len(warnText) = 0, "�Ȃ�", warnText)
    txt = ""
    For i = 0 To n - 1
        res.cells(15 + i, 10).Value2 = labels(i): res.cells(15 + i, 11).Value2 = p(i)
        txt = txt & labels(i) & " = " & Format(p(i), "0.000") & " m" & vbLf
    Next i
    WTInvResult = "���茋��" & vbLf & txt & "����RMS = " & Format(rms, "0.0000") & " m�i" & m & "�_�A�����" & evalCount & "��j" & vbLf & _
                  IIf(Len(warnText) = 0, "", "���ӁF" & warnText & vbLf) & "����l�͐Z�����͂�K��ɏ����߂��Ă��܂���i�Z������ J15�ȍ~�j�B"
    SUnkReady = True
End Sub

Public Sub RPX_WTWriteMode(ByVal mode As Long)
    Dim res As Worksheet
    Set res = RPX_Sheet("�Z������")
    res.Range("J10").Value2 = "���[�h"
    res.Range("K10").Value2 = Choose(mode + 1, "0�F�Z����FEM", "1�F�n�����ʁ{cos2�ƕ␳", "2�F�n�����ʁi�Ð����j", "3�F���m���E�����̋t����")
End Sub

' ---------------------------------------------------------------- self test
Public Function RPX_SeepWaterTableSelfTest() As String
    Dim msg As String, th As Double, i As Long, j As Long, nx As Long, ny As Long, x As Double, y As Double, hw As Double, u As Double, emax As Double
    Dim obsX(0 To 4) As Double, obsY(0 To 4) As Double, p(0 To 0) As Double, labels(0 To 0) As String, rms As Double, warnText As String
    Dim seg() As Double, ns As Long, found As Boolean, started As Double
    On Error GoTo Failed
    started = Timer
    ' 1) �����ΖʁFu = ��w�~hw�~cos2��
    th = 30# * 3.14159265358979 / 180#
    WTN = 2: ReDim WTX(0 To 1): ReDim WTY(0 To 1)
    WTX(0) = -10#: WTY(0) = 10# * Tan(th) - 2#: WTX(1) = 50#: WTY(1) = -50# * Tan(th) - 2#
    For i = 0 To 40
        For j = 0 To 12
            x = i: y = -Tan(th) * x - 6# * j / 12#
            hw = (-Tan(th) * x - 2#) - y
            u = 9.81 * (RPX_WTHead(x, y, 1) - y)
            If hw > 0# Then
                If Abs(u - 9.81 * hw * Cos(th) ^ 2) > emax Then emax = Abs(u - 9.81 * hw * Cos(th) ^ 2)
            End If
            If Abs(9.81 * (RPX_WTHead(x, y, 2) - y) - 9.81 * hw) > emax Then emax = Abs(9.81 * (RPX_WTHead(x, y, 2) - y) - 9.81 * hw)
        Next j
    Next i
    msg = "1) �����Ζ� ��=30���Fmax|u�|��w�~hw�~cos2��|�i���[�h1�j�Emax|u�|��w�~hw|�i���[�h2�j= " & Format(emax, "0.0E+00") & " kPa �� " & IIf(emax < 0.000001, "���i", "�s���i") & vbLf
    ' 2) �t��́FH1=10 �̋�`�_���i20�~10�j����ϑ�5�_�����A�����l8���畜��
    wtTest = True: wtTestNx = 20: wtTestNy = 10
    BuildTestDam 10#: RPX_SeepSolve
    ns = RPX_SeepFreeSurface(seg)
    For i = 0 To 4
        obsX(i) = 2# + 3# * i: obsY(i) = RPX_WTSurfaceY(seg, ns, obsX(i), found)
    Next i
    ReDim SUnkVal(0 To 0): SUnkCount = 1: p(0) = 8#: labels(0) = "�㗬����H1"
    Invert Nothing, p, 1, labels, obsX, obsY, 5, 0#, 20#, 40, rms, warnText
    msg = msg & "2) �t��́FH1 ���� " & Format(p(0), "0.0000") & "�i�^�l10�A�덷 " & Format(100# * (p(0) - 10#) / 10#, "0.000") & "%�j�ARMS " & Format(rms, "0.0E+00") & " m�A����� " & evalCount & " �� �� " & _
          IIf(Abs(p(0) - 10#) < 0.1, "���i", "�s���i") & IIf(Len(warnText) > 0, "�i���ӁF" & warnText & "�j", "") & vbLf
    GoTo Done
Failed:
    msg = msg & "���ȃe�X�g���s�F" & err.number & " " & err.description & vbLf
    Resume Done
Done:
    On Error Resume Next
    wtTest = False: SUnkReady = False
    msg = msg & "���v " & Format(Timer - started, "0.0") & " �b"
    Debug.Print msg
    RPX_SeepWaterTableSelfTest = msg
End Function
