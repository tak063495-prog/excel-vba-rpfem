from pathlib import Path
import argparse, hashlib, json, subprocess, sys
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
manifest=json.loads((root/'EVIDENCE_MANIFEST.json').read_text(encoding='utf8'))
for name,expected in manifest['files'].items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:
        raise SystemExit('Evidence bytes changed: '+name)
args.output.mkdir(parents=True,exist_ok=False)
for case in manifest['cases']:
    out=(args.output/(case['case']+'.json')).resolve()
    command=[sys.executable,'-X','utf8',str(root/case['auditor']),
             '--case',case['case'],'--folder',str(root/case['folder']),
             '--target-gap','.02','--output',str(out)]
    subprocess.run(command,cwd=root,check=True,timeout=180)
    result=json.loads(out.read_text(encoding='utf8'))
    if not result.get('target_met') or not result.get('root_complete'):
        raise SystemExit('Replay failed: '+case['case'])
print('Verified saved-field pairs:',len(manifest['cases']),
      '; no new optimization; cold execution statuses remain in the manifest')
