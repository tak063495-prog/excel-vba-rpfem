from pathlib import Path
import json,hashlib,shutil
REPO=Path(__file__).resolve().parents[3]
ROOT=Path(__file__).resolve().parents[1]
SOURCE=REPO/'versions/G1R17/delivery/RPFEM_20261012_G1R17_P06N_Coarse_Checked.xlsm'
DLL=SOURCE.parent/'rpfem_native_x64.dll'
SOURCE_SHA='dcbfdcfb2d4bbcf382f07d237e77d7122185ebe91c4fce59935cb751f04e2fda'
DLL_SHA='72aaf9bfccc0acc186eb69cdcbabd93b27f7ce245ceac574193ba6602c675323'
CASE_IDS=[c['id'] for c in json.loads((REPO/'versions/G1R13/validation_runtime/data/cases.json').read_text(encoding='utf8'))]
ORDER=['D08A']+[c for c in CASE_IDS if c not in ['D08A','P06A','P06N']]+['P06N','P06A']
assert len(ORDER)==len(set(ORDER))==26
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf8',newline='\n');temp.replace(path)
def prepare():
    assert sha(SOURCE)==SOURCE_SHA and sha(DLL)==DLL_SHA
    records=[]
    for case in ORDER:
        p=ROOT/'inputs'/f'{case}.json';r=json.loads(p.read_text(encoding='utf8'))
        assert r['case']==case and r['settings']['TARGET']==1536 and r['settings']['ADAPT']==1 and r['settings']['CYCLES']==3 and r['settings']['QUADRATURE']==8
        assert bool(r['water']['coupling'])==(case=='D08A')
        records.append({'case':case,'input_sha256':sha(p),'pore_pressure':bool(r['water']['coupling']),'area':r['source_case']['area'],'weight':r['total_weight']})
    write(ROOT/'case_manifest.json',{'source_commit':'24bb5c1a09cf7c92997c347ad9f0ee6868e28475','source_sha256':SOURCE_SHA,'dll_sha256':DLL_SHA,'dll_abi':'0x00170005','catalog_sha256':sha(ROOT/'Test_Case_Catalog.md'),'run_order':ORDER,'cases':records,'scope':'Fresh latest-DLL standard26 sequential native Excel timings, including D08A; no new VBA full timings'})
    shutil.copyfile(DLL,ROOT/'workbooks/rpfem_native_x64.dll')
    write(ROOT/'results/published_package_before.json',{str(p.relative_to(REPO/'versions/G1R17')).replace('\\','/'):sha(p) for p in (REPO/'versions/G1R17').rglob('*') if p.is_file()})
    print('PASS latest G1R17 source/DLL hashes and all26 standard-profile inputs',flush=True)
if __name__=='__main__':prepare()
