"""Explain observed precision limits from actual logs; never grade by gap alone."""
import csv,json,shutil
from prepare import ROOT,ORDER,write
from report import LABELS

def generate():
    records=[];table=['# 採用精度と最終確認の記録','',
        '実行済みの診断ログを確認した記録。Fs取得と、指定した積分次数8を含む最終確認の完了を区別する。',
        '上下界ギャップが1%以下でも、最終確認が未達なら目標達成とは扱わない。','',
        '| ケース | 判定 | 採用積分次数 下/上 | 精度・最終確認の記録 |',
        '|---|---|---|---|']
    for case in ORDER:
        p=ROOT/'cases'/case/'status.json'
        if not p.exists():continue
        r=json.loads(p.read_text(encoding='utf8'))
        if r['status'] in ['RUNNING','PREPARING']:continue
        log=ROOT/'cases'/case/'analysis.tsv';rejections=[];budget=[]
        if log.exists():
            with log.open(encoding='utf16') as f:
                for e in csv.DictReader(f,delimiter='\t'):
                    if e['event']=='final_candidate_rejected':rejections.append({k:e[k] for k in ['elapsed_s','solve_id','candidate','mode','strength_factor','detail']})
                    if e['event']=='solve_end' and 'HSD_SOLVE_BUDGET_EXCEEDED' in e['detail']:budget.append({k:e[k] for k in ['elapsed_s','solve_id','candidate','mode','strength_factor','detail']})
        if rejections:
            reason=' / '.join(e['detail'] for e in rejections)
        elif r.get('target_met'):reason='指定目標と独立監査を達成'
        elif r.get('fs_obtained'):reason=' / '.join(r.get('target_unmet_reasons',[]))
        else:reason=r.get('error','Fs未取得')
        q=r.get('witness_q',[])
        table.append('| '+case+' | '+LABELS.get(r['status'],r['status'])+' | '+('/'.join(map(str,q)) or '—')+' | '+reason.replace('|','/')+' |')
        records.append({'case':case,'status':r['status'],'adopted_quadrature':q,'fs_obtained':r.get('fs_obtained'),
            'target_met':r.get('target_met'),'target_unmet_reasons':r.get('target_unmet_reasons',[]),
            'final_rejections':rejections,'hsd_budget_exceeded_solves':budget})
    write(ROOT/'results/quality_notes.json',{'completed_cases':len(records),'cases':records})
    (ROOT/'QUALITY_NOTES.md').write_text('\n'.join(table)+'\n',encoding='utf8')
    dest=__import__('pathlib').Path('C:/Users/link_/Desktop/RPFEM_G1R17_Native26_20261012')
    if dest.exists():shutil.copyfile(ROOT/'QUALITY_NOTES.md',dest/'QUALITY_NOTES.md')
    print('OBSERVED_QUALITY_NOTES',len(records),'completed cases')
    return records

if __name__=='__main__':generate()
