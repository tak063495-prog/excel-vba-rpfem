"""Reconstruct all26 catalog inputs without opening Excel or modifying originals."""
import importlib.util, json, re, os
from prepare import ROOT, REPO, ORDER, write, sha

catalog=(ROOT/'Test_Case_Catalog.md').read_text(encoding='utf8')
os.environ['RPFEM_REPO']=str(REPO)
os.environ['RPFEM_CATALOG']=str(ROOT/'Test_Case_Catalog.md')
spec=importlib.util.spec_from_file_location('catalog_encoder',REPO/'validation/G1R12_native25_20261009/scripts/prepare_inputs.py')
encoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(encoder)
checks=[]
for case in ORDER:
    path=ROOT/'inputs'/f'{case}.json';record=json.loads(path.read_text(encoding='utf8'));c=record['source_case']
    section=re.search(r'^### '+case+r' .*?(?=^### |\Z)',catalog,re.M|re.S)[0]
    assert encoder.pairs(re.search(r'外形（反時計回り）: `([^`]+)`',section)[1])==c['outline'],case
    mats=re.findall(r'^\| ([^|]+) \| ([\d.e+-]+) \| ([\d.e+-]+) \| ([\d.e+-]+) \| ([\d.e+-]+) \| ([\d.e+-]+) \| ([\d.e+-]+) \|',section,re.M)
    assert len(mats)==len(c['materials']),case
    for row,m in zip(mats,c['materials']):
        assert row[0].strip()==m['name'] and list(map(float,row[1:]))==[m[k] for k in ['E','nu','gamma','c','phi','psi']],case
    regions=re.findall(r'^- `([^`]+)`: `([^`]+)`',section,re.M)
    assert [{'name':name,'xy':encoder.pairs(coords)} for name,coords in regions]==c['regions'],case
    expected=json.loads(json.dumps(encoder.emit(c)))
    for key in ['points','materials','regions','faces','boundary_explicit','region_areas','total_weight']:
        assert record[key]==expected[key],(case,key)
    for key,value in expected['settings'].items():assert record['settings'][key]==value,(case,key)
    assert record['settings']['SEISMIC_KH']==0. and record['settings']['SEISMIC_DIR']=='右(+x)'
    if case=='D08A':
        pore=json.loads(re.search(r'間隙水圧: `([^`]+)`',section)[1])
        assert pore==record['water']['catalog_spec'] and pore['mode']=='fixed_hydrostatic'
        assert record['water']['water_table']==[[0.,3.],[20.,3.]] and record['water']['gamma_w']==9.81 and record['water']['coupling']==1 and record['water']['suction']==0
    else:assert record['water']['coupling']==0 and not record['water']['water_table']
    checks.append({'case':case,'pass':True,'input_sha256':sha(path)})
write(ROOT/'results/catalog_input_verification.json',{'pass':True,'cases':checks,'scope':'Catalog outlines, materials, regions; reconstructed explicit boundaries, loads, areas/weights, case policy/settings and D08A fixed water'})
print('PASS26 catalog reconstruction, complete boundaries/loads/materials/policies/water')
