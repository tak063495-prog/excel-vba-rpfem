"""Report actual native Excel measurements, including incomplete/failed runs."""
from pathlib import Path
from datetime import datetime, timezone
import csv, json, math, statistics, sys, zipfile
from prepare import ROOT, REPO, SOURCE, DLL, SOURCE_SHA, DLL_SHA, ORDER, sha, write

OLD = Path('C:/Users/link_/Downloads/RPFEM_DLL2_Native25_20261012/validation/G1R15_DLL2_native26_20261012')
TERMINAL = {'PASS_TARGET', 'FS_AVAILABLE_PARTIAL', 'FAILED', 'AUDIT_FAILED', 'HARNESS_OR_EXPORT_ERROR', 'CANCELLED_BY_USER'}
LABELS = {'NOT_RUN':'未実行','PREPARING':'準備中','RUNNING':'解析中','PASS_TARGET':'目標達成',
          'FS_AVAILABLE_PARTIAL':'Fs取得・精度目標未達','FAILED':'Fs未取得','AUDIT_FAILED':'独立監査未達',
          'HARNESS_OR_EXPORT_ERROR':'計測・保存エラー','CANCELLED_BY_USER':'ユーザー中断'}
NUMERICAL_COUNTERS = ['numeric','dd_numeric','nt_bulk','hsd_jobs','hsd_lu','schur_jobs']
PROFILE_KEYS = ['MODE','TARGET','GRAVITY','ADAPT','CYCLES','GAP','REFINE','QUADRATURE','FS_TOL','ANALYSIS_POLICY',
                'SEISMIC_KH','SEISMIC_DIR','ADAPT_MESH_POLICY','ADAPT_REFINE_CAP','C0_AUTO','RAW_LOWER_AUDIT']

def number(value, places=6):
    return f'{value:.{places}f}' if isinstance(value,(int,float)) and math.isfinite(value) else '—'

def rows():
    records=[]
    for case in ORDER:
        path=ROOT/'cases'/case/'status.json'
        r=json.loads(path.read_text(encoding='utf8')) if path.exists() else {'case':case,'status':'NOT_RUN'}
        counters={k:int(v) for token in r.get('native_end','').split(';')[1:] if '=' in token for k,v in [token.split('=',1)]}
        r['native_counters']=counters
        r['dll_actually_used']=r.get('native_end','').startswith('DLL_READY;') and sum(counters.get(k,0) for k in NUMERICAL_COUNTERS)>0
        old_path=OLD/'cases'/case/'status.json'
        if old_path.exists() and r['status'] in TERMINAL and r.get('analysis_seconds'):
            old=json.loads(old_path.read_text(encoding='utf8'))
            if old.get('fs_obtained'):
                old_input=json.loads((OLD/'inputs'/f'{case}.json').read_text(encoding='utf8'))
                current=json.loads((ROOT/'inputs'/f'{case}.json').read_text(encoding='utf8'))
                old_input.pop('scope_notes',None);current.pop('scope_notes',None)
                assert old_input==current,(case,'physical input changed')
                differences={k:{'old':old.get('actual_settings',{}).get(k),'new':r.get('actual_settings',{}).get(k)} for k in PROFILE_KEYS if old.get('actual_settings',{}).get(k)!=r.get('actual_settings',{}).get(k)}
                r['previous_dll2']={'seconds':old.get('analysis_seconds'),'lower_fs':old.get('lower_fs'),'upper_fs':old.get('upper_fs'),
                    'input_match':True,'profile_differences':differences,'element_counts_match':old.get('element_counts')==r.get('element_counts'),
                    'fs_close':r.get('fs_obtained') and all(math.isclose(r[k],old[k],rel_tol=1e-10,abs_tol=1e-10) for k in ['lower_fs','upper_fs']),
                    'reference_speed_ratio':old['analysis_seconds']/r['analysis_seconds'] if not differences and r.get('fs_obtained') else None,
                    'limit':'Same-PC previous DLL2 measurement, no interleaved repeat; whole-version ratio, not isolated DLL-only effect',
                    'old_status_sha256':sha(old_path)}
                r['previous_dll2']['witness_binary_matches']={side:sha(ROOT/'cases'/case/f'witness_{side}.bin')==sha(OLD/'cases'/case/f'witness_{side}.bin') for side in ['lower','upper'] if (ROOT/'cases'/case/f'witness_{side}.bin').exists() and (OLD/'cases'/case/f'witness_{side}.bin').exists()}
        records.append(r)
    return records

def generate(final=False):
    records=rows();done=[r for r in records if r['status'] in TERMINAL];full=[r for r in done if r['status']!='CANCELLED_BY_USER']
    if final:assert len(full)==26,'26 actual non-cancelled terminal records required'
    measured=[r for r in full if isinstance(r.get('analysis_seconds'),(int,float))]
    if final:assert len(measured)==26,'Missing native run_end timings require investigation before final reporting'
    if final:
        assert all(r['dll_actually_used'] for r in full),'Every case must prove actual numerical DLL calls'
        assert all(r.get('production_source_check',{}).get('pass') for r in full),'Every case must preserve production modules'
    times=[r['analysis_seconds'] for r in measured]
    summary={'updated_utc':datetime.now(timezone.utc).isoformat(),'final':final,'count':26,'completed':len(full),
        'fs_obtained':sum(bool(r.get('fs_obtained')) for r in full),'target_met':sum(bool(r.get('target_met')) for r in full),
        'cancelled':sum(r['status']=='CANCELLED_BY_USER' for r in records),'not_run':sum(r['status']=='NOT_RUN' for r in records),
        'analysis_seconds_sum':sum(times),'analysis_seconds_mean':statistics.mean(times) if times else None,
        'analysis_seconds_median':statistics.median(times) if times else None,'dll_actually_used_count':sum(r['dll_actually_used'] for r in full),
        'production_preserved_count':sum(bool(r.get('production_source_check',{}).get('pass')) for r in full),
        'failures':[{'case':r['case'],'status':r['status'],'error':r.get('error')} for r in full if not r.get('fs_obtained')],
        'cases':records}
    write(ROOT/'results'/('final_summary.json' if final else 'interim_summary.json'),summary)
    columns=['case','status','analysis_seconds','analysis_minutes','com_analysis_seconds','seep_seconds','mesh_seconds',
        'lower_fs','upper_fs','gap_percent','fs_obtained','target_met','target_unmet_reasons','element_counts','witness_q',
        'solve_count','audit_count','intermediate_audit_rejections','sampled_peak_memory_mb','dll_actually_used','native_end',
        'pore_pressure','error_number','error','previous_dll2_seconds','reference_speed_ratio']
    temporary=ROOT/'RESULTS.csv.tmp'
    with temporary.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
        for r in sorted(records,key=lambda v:v['case']):
            row={k:r.get(k,'') for k in columns};log=r.get('log_summary',{});old=r.get('previous_dll2',{})
            row.update(analysis_minutes=r['analysis_seconds']/60 if r.get('analysis_seconds') is not None else '',
                gap_percent=100*r['relative_gap'] if isinstance(r.get('relative_gap'),(int,float)) else '',
                solve_count=log.get('solve_count',''),audit_count=log.get('audit_count',''),
                intermediate_audit_rejections=len(log.get('audit_rejections',[])),previous_dll2_seconds=old.get('seconds',''),
                reference_speed_ratio=old.get('reference_speed_ratio',''))
            peak=log.get('terminal',{}).get('sampled_peak_private_bytes');row['sampled_peak_memory_mb']=float(peak)/1048576 if peak else ''
            for k in ['target_unmet_reasons','element_counts','witness_q']:
                if k in r:row[k]=json.dumps(r[k],ensure_ascii=False)
            writer.writerow(row)
    temporary.replace(ROOT/'RESULTS.csv')
    phases=sorted({key for r in full for key in r.get('log_summary',{}).get('phase_seconds',{})})
    with (ROOT/'PHASE_TIMINGS.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['case','status','analysis_seconds']+phases);writer.writeheader()
        for r in sorted(records,key=lambda v:v['case']):writer.writerow({'case':r['case'],'status':r['status'],'analysis_seconds':r.get('analysis_seconds',''),**r.get('log_summary',{}).get('phase_seconds',{})})
    table=['| ケース | 判定 | 主解析秒 | 分 | Fs下界 | Fs上界 | GAP % |','|---|---|---:|---:|---:|---:|---:|']
    for r in sorted(records,key=lambda v:v['case']):
        table.append('| '+r['case']+' | '+LABELS.get(r['status'],r['status'])+' | '+number(r.get('analysis_seconds'),2)+' | '+number(r['analysis_seconds']/60 if r.get('analysis_seconds') is not None else None,2)+' | '+number(r.get('lower_fs'))+' | '+number(r.get('upper_fs'))+' | '+number(100*r['relative_gap'] if isinstance(r.get('relative_gap'),(int,float)) else None,3)+' |')
    quality_path=ROOT/'results/quality_notes.json'
    quality=json.loads(quality_path.read_text(encoding='utf8')) if quality_path.exists() else {'cases':[]}
    final_budget_cases=[r['case'] for r in quality['cases'] if any('HSD_SOLVE_BUDGET_EXCEEDED' in e['detail'] for e in r.get('final_rejections',[]))]
    quality_note=('実測では '+', '.join(final_budget_cases)+' の積分次数8での最終確認がHSDの300秒予算に達した。\n'
        'これらは保存済みの監査済み上下界場を保持しており、最終精度目標達成には数えない。\n') if final_budget_cases else ''
    quality_note+='各ケースの採用積分次数・最終候補の棄却理由はQUALITY_NOTES.mdを参照。'
    comparisons=[r for r in full if r.get('previous_dll2',{}).get('reference_speed_ratio') is not None]
    paired_note=''
    if comparisons:
        paired_ratio=sum(r['previous_dll2']['seconds'] for r in comparisons)/sum(r['analysis_seconds'] for r in comparisons)
        identical=sum(r['previous_dll2'].get('witness_binary_matches')=={'lower':True,'upper':True} for r in comparisons)
        paired_note=f'過去のDLL2と条件を照合できた{len(comparisons)}ケースでは、主時間合計の比が{paired_ratio:.3f}倍。\n上下界の保存場バイナリは{identical}/{len(comparisons)}ケースで両方とも完全一致した。\n'
    report=f'''# G1R17・最新DLL5：間隙水圧を含む26ケースの速度実測

更新UTC: {summary['updated_utc']}。状態: {'最終' if final else '測定途中'}。
完了 {len(full)}/26、独立監査を通ったFs取得 {summary['fs_obtained']}/26、精度目標達成 {summary['target_met']}/26。
主解析時間の合計 {sum(times):.2f}秒（{sum(times)/3600:.3f}時間）。中断時間は完走時間に含めない。

## 計測条件

- 公開G1R17コミット `24bb5c1a09cf7c92997c347ad9f0ee6868e28475`、DLL ABI `0x00170005`。
- XLSM SHA-256 `{SOURCE_SHA}`、DLL SHA-256 `{DLL_SHA}`。
- TARGET=1536、ADAPT=1、CYCLES=3、QUADRATURE=8、FS_TOL=1e-4、GAP=0.01、kh=0、C0_AUTO=0。
- 公開版の探索、LDL・DD・NT・HSD、許容差、監査、冷開始、適応メッシュ上限を保持。実際の全設定を各status.jsonに保存。
- HSD求解予算は公開G1R17ブックの300秒/求解。結果が未判定の場合も記録する。
- HSD内の開始時刻から反復境界で予算を検査する。準備・通常求解も含む固定Fsのwall_secondsが300秒を超えるだけでは予算超過とは判定せず、実際のhsd_budget・solve_endの記録で区別する。
- AMD Ryzen 9 5900X、64bit Excel 16.0、Windows 11。Excel解析は1ケースずつ順次実行。
- 主時間は診断ログ `run_end.elapsed_s`。COMのRPX_Run時間も併記。水圧準備、初期メッシュ、Excel起動終了、保存、独立Python監査は主時間に含めない。
- VBAのみの全解析は再計測していない。事前確認用D08AのTARGET32/q2計算は本測定へ合算しない。

## ケース別結果

{chr(10).join(table)}

詳細はRESULTS.csv、区間別時間はPHASE_TIMINGS.csv。計測区間には入れ子があり、列の単純合計は総解析時間にならない。

## 判定と精度

「目標達成」は根探索の採用場の有効・完了フラグ、上下界ギャップ1%、独立物理監査を満たす。
「Fs取得・精度目標未達」は独立監査済み上下界を取得したが、ギャップまたは探索精度の目標が未達。
未実行、解析中、失敗、計測・保存処理の失敗、ユーザー中断は区別する。途中の棄却候補も解析ログに保持する。
Aは関連流れ則、Nは現行のDavis等価関連モデル。構成則とFsの定義は変更していない。
D04AのE、D09Aのνはこの剛塑性モデルの入力に含まれない。両ケースも実行するが、その感度検証には数えない。

{quality_note}

## 間隙水圧と独立検証

D08Aは地下水位y=3の固定静水圧 `u=9.81*max(3-y,0)`、連成ON、サクションOFF。全単位体積重量γ=20を保持。
露出面が地下水位より上なので追加外水圧荷重なし。浸透FEMの反復解ではなく、指定された水圧場を生成して連成する。
他25ケースはカタログどおり連成OFF。節点水圧を指定式と照合し、独立PythonでP1水圧勾配と `b-grad u` を計算する。
保存した上下界場の材料・領域面積・外周境界・自重・上載荷重・降伏・平衡・面力・速度境界・内部面ジャンプ・仕事を監査する。
下界の物理残差は元単位に戻し1e-7以下を要求する。Fs取得は独立監査を通った場合に限る。

## 保全と再現

原本XLSM・DLLは変更せず、ネイティブExcelで別コピーを作成。追加は記録用標準モジュールBatchEvidenceのみ。
製品71モジュールと文書モジュールは保存時に照合。マクロセキュリティ・信頼設定・レジストリを変更していない。
各ケースで実DLL呼出し回数を記録し、VBAフォールバックをDLL実測に数えない。
`workbooks/`はケース別結果XLSMと共通DLL、`cases/<ID>/`はログ・状態・保存上下界場、`inputs/`は照合済み入力。
`scripts/runner.py batch`で未実行ケースを再開できる。RUNNING/PREPARINGのまま残ったケースは内容を確認せず再実行しない。
ユーザー中断はSTOPファイルと通常のRPX_Stopで要求し、他のExcelを終了しない。
過去のDLL2実測があるケースは同じ物理入力・公開プロファイルを確認し参考比をCSVへ保存する。
参考比は版全体の比較で、交互反復測定やDLL単独の効果の証明ではない。過去の値を今回の実測として使わない。
{paired_note}
再実行に必要な配置と依存関係はREPRODUCTION_JA.mdを参照。測定日は2026-10-12開始で、保存フォルダーの日付は開始日を保持する。
'''
    temp=ROOT/'REPORT.md.tmp';temp.write_text(report,encoding='utf8',newline='\n');temp.replace(ROOT/'REPORT.md')
    print(json.dumps({k:summary[k] for k in ['completed','final','fs_obtained','target_met','analysis_seconds_sum','failures']},ensure_ascii=False))
    return summary

def package():
    summary=generate(True)
    assert sha(SOURCE)==SOURCE_SHA and sha(DLL)==DLL_SHA
    manifest=json.loads((ROOT/'results/published_package_before.json').read_text(encoding='utf8'))
    assert all(sha(REPO/'versions/G1R17'/name)==h for name,h in manifest.items())
    write(ROOT/'results/published_package_after.json',{'pass':True,'protected_files':len(manifest),'source_sha256':SOURCE_SHA,'dll_sha256':DLL_SHA})
    files=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix in {'.pyc','.tmp'}:continue
        rel=p.relative_to(ROOT)
        # Delivery metadata contains the archive hash and must remain outside that archive.
        if p.name in {'MANIFEST.json','SHA256SUMS.txt','prepared_template.xlsm','desktop_delivery.json'}:continue
        if rel.parts[:2]==('workbooks','RPFEM_logs'):continue
        if p.name.startswith('G1R17_DLL5_SMOKE_'):continue
        files.append(p)
    hashes={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in files}
    write(ROOT/'MANIFEST.json',hashes)
    (ROOT/'SHA256SUMS.txt').write_text(''.join(h+'  '+name+'\n' for name,h in sorted(hashes.items())),encoding='utf8')
    files.extend([ROOT/'MANIFEST.json',ROOT/'SHA256SUMS.txt'])
    target=REPO/'RPFEM_G1R17_Native26_20261012.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,'G1R17_native26/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for name,h in hashes.items():assert __import__('hashlib').sha256(z.read('G1R17_native26/'+name)).hexdigest()==h
    print('PACKAGE PASS',target,'bytes',target.stat().st_size)

if __name__=='__main__':
    if '--package' in sys.argv:package()
    else:generate('--final' in sys.argv)
