"""Compare only actually completed, audited measurements with prior DLL2."""
from prepare import ROOT,write
from report import rows
records=[{'case':r['case'],**r['previous_dll2']} for r in rows() if r.get('fs_obtained') and 'previous_dll2' in r]
binary_matches=sum(r.get('witness_binary_matches')=={'lower':True,'upper':True} for r in records)
write(ROOT/'results/prior_dll2_comparison.json',{'compared_cases':len(records),'both_witnesses_bitwise_equal':binary_matches,'cases':records,
    'scope':'Actual current native Excel results versus the earlier same-PC standard profile; no earlier timings reused as current measurements'})
print('ACTUAL_PREVIOUS_COMPARISON',len(records),'cases; both complete witness binaries match:',binary_matches)
