import zipfile,xml.etree.ElementTree as ET
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def cells(path):
    with zipfile.ZipFile(path) as z:
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():shared=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',NS)]
        rels={e.attrib['Id']:e.attrib['Target'] for e in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))};result={}
        for sheet in ET.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',NS):
            rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'];target=rels[rid]
            target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            data={}
            for cell in ET.fromstring(z.read(target)).findall('.//s:sheetData/s:row/s:c',NS):
                value=cell.find('s:v',NS);kind=cell.get('t')
                if kind=='inlineStr':v=''.join(cell.find('s:is',NS).itertext())
                elif value is None or value.text is None:continue
                elif kind=='s':v=shared[int(value.text)]
                elif kind in ('str','e'):v=value.text
                elif kind=='b':v=bool(int(value.text))
                else:v=float(value.text)
                data[cell.attrib['r']]=v
            result[sheet.attrib['name']]=data
        return result
