from pathlib import Path
import json,sys,time,datetime
from prepare import ROOT,ORDER
def snapshot():
    states=[]
    for case in ORDER:
        path=ROOT/'cases'/case/'status.json'
        states.append(json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'case':case,'status':'NOT_RUN'})
    finished=[s for s in states if s['status'] not in ['NOT_RUN','PREPARING','RUNNING']]
    active=[s for s in states if s['status'] in ['PREPARING','RUNNING']]
    result={'finished':len(finished),'total':26,'audited_fs':sum(s.get('fs_obtained',False) for s in finished),
        'target_met':sum(s.get('target_met',False) for s in finished),'failed':[{'case':s['case'],'status':s['status'],'error':s.get('error')} for s in finished if not s.get('fs_obtained')],
        'completed':[{'case':s['case'],'seconds':s.get('analysis_seconds'),'status':s['status'],'lower':s.get('lower_fs'),'upper':s.get('upper_fs')} for s in finished]}
    for s in active:
        row={'case':s['case'],'status':s['status'],'excel_pid':s.get('excel_pid')}
        if s.get('run_started_utc'):
            row['wall_elapsed_seconds']=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(s['run_started_utc'])).total_seconds()
        files=list((ROOT/'workbooks/RPFEM_logs').glob(f"*_{s.get('excel_pid')}_analysis.tsv"))
        if files:
            path=max(files,key=lambda p:p.stat().st_mtime)
            with path.open('rb') as f:
                f.seek(max(2,path.stat().st_size-16384));offset=f.tell()
                if offset%2:f.read(1)
                text=f.read().decode('utf-16-le',errors='replace')
            lines=[v.split('\t') for v in text.splitlines() if len(v.split('\t'))>=10]
            if lines:
                last=lines[-1];row.update({'log_elapsed_seconds':last[1],'solve_id':last[2],'candidate':last[3],'side':last[4],'fixed_fs':last[5],'event':last[6],'detail':last[-1]})
            row['log']=str(path.relative_to(ROOT))
        result['active']=row
    return result
if __name__=='__main__':
    data=snapshot()
    if '--compact' in sys.argv:data['completed']=data['completed'][-3:]
    if '--brief' in sys.argv:data.pop('completed',None)
    print(json.dumps(data,ensure_ascii=False,indent=2))
