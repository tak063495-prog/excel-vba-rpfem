import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import argparse,json,csv,shutil,hashlib,time,sys,gc,traceback,subprocess
from datetime import datetime,timezone
import win32com.client,win32process,pythoncom,threading,win32gui,win32con
from controls import start_controls
from prepare import ROOT,REPO,SOURCE,DLL,SOURCE_SHA,DLL_SHA,ORDER,sha,write
from native_helpers import compile_book
from grade_results import grade
from audit_case import audit_case
TEMPLATE=ROOT/'prepared_template.xlsm'
def utc():return datetime.now(timezone.utc).isoformat()
def macros(path):
    from oletools.olevba import VBA_Parser
    parser=VBA_Parser(str(path))
    try:return {name:code.replace('\r\n','\n') for _,_,name,code in parser.extract_macros()}
    finally:parser.close()
def production_check(path):
    # Native Excel canonicalizes source when adding the evidence module.
    from verify_source import canonical
    before=macros(SOURCE);after=macros(path)
    assert set(after)==set(before)|{'BatchEvidence.bas'}
    for name in before:assert canonical(before[name])==canonical(after[name]),name
    return {'pass':True,'unchanged_original_modules':len(before),'only_added_module':'BatchEvidence','document_modules_unchanged':True}
def prepare_template():
    assert not TEMPLATE.exists() and sha(SOURCE)==SOURCE_SHA and sha(DLL)==DLL_SHA
    shutil.copyfile(SOURCE,TEMPLATE);app=None;book=None
    try:
        app=win32com.client.DispatchEx('Excel.Application');app.Visible=False;app.DisplayAlerts=False
        book=app.Workbooks.Open(str(TEMPLATE),UpdateLinks=0)
        comp=book.VBProject.VBComponents.Add(1);comp.Name='BatchEvidence'
        text=(ROOT/'tests/BatchEvidence.bas').read_text(encoding='utf-8')
        comp.CodeModule.AddFromString('\r\n'.join(s for s in text.splitlines() if not s.startswith('Attribute VB_')))
        compile_book(app,book);book.Save()
        data={'compile':'PASS','source_sha256':SOURCE_SHA,'template_sha256':sha(TEMPLATE),'macro_security_unmodified':app.AutomationSecurity}
    finally:
        if book is not None:book.Close(False)
        if app is not None:app.Quit()
        book=None;app=None;gc.collect()
    data['integrity']=production_check(TEMPLATE);write(ROOT/'results/template_check.json',data)
    print('PREPARED TEMPLATE PASS',flush=True)
def settings(book):
    return {str(r[3]):r[1] for r in book.Worksheets('設定').Range('A4:D100').Value2 if r[3]}
def configure(book,rec):
    ws=book.Worksheets('要素定義');ws.Range('A7:T1006').ClearContents()
    for first,last,name in [('A','C','points'),('E','H','regions'),('J','T','faces')]:
        data=tuple(tuple(row) for row in rec[name]);rng=ws.Range(first+'7:'+last+str(6+len(data)))
        rng.Value2=data;assert rng.Value2==data,(rec['case'],name)
    ws=book.Worksheets('材料データ');ws.Range('A5:Q1004').ClearContents()
    data=tuple(tuple(row) for row in rec['materials']);rng=ws.Range('A5:E'+str(4+len(data)))
    rng.Value2=data;assert rng.Value2==data
    ws=book.Worksheets('設定');keys={str(row[3]):4+i for i,row in enumerate(ws.Range('A4:D100').Value2) if row[3]}
    for key,value in rec['settings'].items():
        assert key in keys,('SETTING_MISSING',key)
        ws.Cells(keys[key],2).Value2=value
    actual=settings(book);assert all(actual[k]==v for k,v in rec['settings'].items())
    water=rec['water'];ws=book.Worksheets('浸透入力');assert ws.Range('Z1').Value2=='RPX_SEEP_LAYOUT_V2'
    ws.Range('A7:C206,E7:K206,M7:N206,P7:Q206').ClearContents()
    ws.Range('B3').Value2=ws.Range('Z6').Value2 # static groundwater level, mode=2
    ws.Range('B4').Value2=water['gamma_w'];ws.Range('D4').Value2=water['coupling'];ws.Range('F4').Value2=water['suction']
    ws.Range('C209').Value2=water['seep_target']
    if water['water_table']:ws.Range('M7:N8').Value2=tuple(tuple(row) for row in water['water_table'])
    for i,m in enumerate(rec['materials'],7):ws.Range(f'A{i}:C{i}').Value2=((m[0],1.,1.),)
    if water['coupling']:
        assert ws.Range('M7:N8').Value2==tuple(tuple(row) for row in water['water_table'])
    assert ws.Range('D4').Value2==water['coupling']
    # The delivery template contains levee seepage output. Dry cases must not
    # display or retain that unrelated field; wet cases regenerate their field.
    book.Worksheets('浸透結果').Cells.ClearContents()
    book.Worksheets('解析結果').Range('A1').Value2='未解析 / '+rec['case']
    for sheet in book.Worksheets:
        if '実行案内' in sheet.Name:sheet.Range('A1').Value2=rec['case']+' / G1R17 DLL5実測。入力表がこのケースの原本。'
    return actual
def read_log(path):return list(csv.DictReader(path.open(encoding='utf-16'),delimiter='\t'))
def parts(value):return dict(p.split('=',1) for p in value.split(';') if '=' in p)
def log_summary(path):
    rows=read_log(path);ends=[r for r in rows if r['event']=='run_end']
    assert len(ends)==1
    audits=[r for r in rows if r['event']=='audit']
    rejected=[r for r in rows if 'audit' in r['event'] and ('status=FAIL' in r['detail'] or 'accepted=0' in r['detail'])]
    solves=[r for r in rows if r['event']=='solve_start']
    return {'analysis_seconds':float(ends[0]['elapsed_s']),'terminal':parts(ends[0]['detail']),
        'solve_count':len(solves),'audit_count':len(audits),'audit_rejections':rejected,
        'phase_seconds':{parts(r['detail'])['phase']:float(parts(r['detail'])['seconds']) for r in rows if r['event']=='run_phase'},
        'log_sha256':sha(path)}
def worker(case,smoke=False):
    pythoncom.CoInitialize();app=None;book=None;control_stop=None;tick=time.perf_counter()
    tag=('SMOKE_' if smoke else '')+case;folder=(ROOT/'harness_validation' if smoke else ROOT/'cases')/case
    folder.mkdir(parents=True,exist_ok=True)
    rec=json.loads((ROOT/'inputs'/f'{case}.json').read_text(encoding='utf-8'))
    if smoke:rec['settings'].update({'TARGET':32,'CYCLES':1,'QUADRATURE':2});rec['water']['seep_target']=32
    path=ROOT/'workbooks'/f'G1R17_DLL5_{tag}_Full.xlsm'
    out={'case':case,'tag':tag,'status':'PREPARING','started_utc':utc(),'pore_pressure':bool(rec['water']['coupling']),
        'source_sha256':SOURCE_SHA,'dll_sha256':DLL_SHA,'input_sha256':sha(ROOT/'inputs'/f'{case}.json'),
        'fs_obtained':False,'target_met':False,'smoke':smoke,'scope_notes':rec['scope_notes']}
    out['runner_sha256']=sha(Path(__file__))
    def persist():
        write(folder/'status.json',out)
        if not smoke:write(ROOT/'results'/f'{case}.json',out)
    try:
        assert not path.exists();assert sha(SOURCE)==SOURCE_SHA and sha(DLL)==DLL_SHA
        shutil.copyfile(TEMPLATE,path)
        app=win32com.client.DispatchEx('Excel.Application');app.Visible=False;app.DisplayAlerts=False
        out['excel_pid']=win32process.GetWindowThreadProcessId(app.Hwnd)[1]
        out['excel_version']=app.Version;out['macro_security_unmodified']=app.AutomationSecurity;persist()
        control_stop=start_controls(app,out['excel_pid'],path.name,folder)
        book=app.Workbooks.Open(str(path),UpdateLinks=0)
        call=lambda name,*args:app.Run("'"+book.Name+"'!"+name,*args)
        out['actual_settings']=configure(book,rec)
        info=str(call('BatchDefinition')).split('\t')
        assert [int(v) for v in info[:3]]==[len(rec['points']),len(rec['regions']),len(rec['faces'])],info
        assert math_close(float(info[3]),rec['source_case']['area']) and info[4]==rec['settings']['ANALYSIS_POLICY']
        out['native_definition']=info
        call('RPX_NativeSetMode','auto');out['native_start']=str(call('RPX_NativeInfo'))
        assert out['native_start'].startswith('DLL_READY'),out['native_start']
        call('RPX_SeepSetSilent',True);out['seep_seconds']=0.
        if rec['water']['coupling']:
            started=time.perf_counter();out['seep_message']=str(call('RPX_SeepRunSilent'));out['seep_seconds']=time.perf_counter()-started
            ws=book.Worksheets('浸透結果');assert ws.Range('K2').Value2 is True,'WATER_FIELD_NOT_READY'
            out['water_source_result']={'converged':ws.Range('K2').Value2,'nodes':ws.Range('K7').Value2,'elements':ws.Range('K6').Value2,'water_stamp':ws.Range('K9').Value2}
            assert '失敗' not in out['seep_message'] and 'ERR ' not in out['seep_message'],out['seep_message']
        call('RPX_SeepSetSilent',True)
        started=time.perf_counter();call('RPX_CreateMesh');out['mesh_seconds']=time.perf_counter()-started
        out['water_definition_check']=str(call('BatchWaterCheck',bool(rec['water']['coupling'])))
        assert out['water_definition_check'].startswith('PASS'),out['water_definition_check']
        call('BatchStagePath',str(folder/'stage.txt'))
        book.Save();out['status']='RUNNING';out['run_started_utc']=utc();persist()
        print('START',tag,'ExcelPID',out['excel_pid'],'TARGET',rec['settings']['TARGET'],'water',rec['water']['coupling'],flush=True)
        started=time.perf_counter();call('RPX_Run');out['com_analysis_seconds']=time.perf_counter()-started
        out['native_end']=str(call('RPX_NativeInfo'))
        assert out['native_end'].startswith('DLL_READY'),out['native_end']
        ws=book.Worksheets('解析結果');out['sheet_status']=ws.Range('A1').Value2
        out['lower_fs'],out['upper_fs']=ws.Range('B4:C4').Value2[0]
        out['relative_gap']=ws.Range('B9').Value2;out['element_counts']=ws.Range('B10:C10').Value2[0]
        out['summary_fields']=str(call('BatchResult',str(folder/'witness'))).split('\t')
        assert not out['summary_fields'][0].startswith('ERROR'),out['summary_fields']
        flags=out['summary_fields'];out['error_number']=int(flags[0]);out['error']=flags[1]
        out['result_current']=flags[3]=='True';out['root_search_incomplete']=flags[4]=='True';out['root_width']=float(flags[5])
        out['diagnostic_path']=flags[7];out['witness_q']=list(map(int,flags[8:10]));out['witness_phase']=flags[10:12]
        log=Path(out['diagnostic_path']);assert log.exists(),str(log)
        shutil.copyfile(log,folder/'analysis.tsv');out['log_summary']=log_summary(folder/'analysis.tsv')
        out['analysis_seconds']=out['log_summary']['analysis_seconds']
        out['fs_values_present']=all(isinstance(v,(int,float)) and 0<v<1e20 for v in [out['lower_fs'],out['upper_fs']]) and out['lower_fs']<=out['upper_fs']
        if out['fs_values_present'] and not out['error_number'] and out['result_current']:
            out['independent_audit']=audit_case(case,folder,rec,out)
            # Rejected intermediate candidates remain recorded. The final native
            # result and its independently audited witnesses determine Fs validity.
            out['fs_obtained']=out['independent_audit']['pass']
            out['status']='SOLVED_AWAITING_AUDIT' if out['fs_obtained'] else 'AUDIT_FAILED'
            if out['fs_obtained']:out=grade(out)
        else:out['status']='CANCELLED_BY_USER' if out['error_number']==18 and (ROOT/'STOP').exists() else 'FAILED'
        out['water_on_at_finish']=bool(call('BatchWaterOn'))
        assert out['water_on_at_finish']==bool(rec['water']['coupling'])
        out['production_source_check']=production_check_live(book)
        book.Save();out['workbook_sha256']=sha(path);out['workbook']=str(path.relative_to(ROOT))
    except Exception as e:
        out['status']='HARNESS_OR_EXPORT_ERROR';out['error']=repr(e);out['traceback']=traceback.format_exc()
        if book is not None:
            try:book.Save();out['workbook']=str(path.relative_to(ROOT));out['workbook_sha256']=sha(path)
            except Exception:out['save_error']=traceback.format_exc()
    finally:
        out['seconds_before_excel_close']=time.perf_counter()-tick;out['finished_utc']=utc();persist()
        if control_stop is not None:control_stop.set()
        if book is not None:
            try:book.Close(False)
            except Exception:out['close_error']=traceback.format_exc()
        if app is not None:
            try:app.Quit()
            except Exception:out['quit_error']=traceback.format_exc()
        book=None;app=None;gc.collect();pythoncom.CoUninitialize()
        out['total_worker_seconds']=time.perf_counter()-tick;persist()
    print('DONE',tag,out['status'],'Fs',out.get('lower_fs'),out.get('upper_fs'),'analysis_seconds',out.get('analysis_seconds'),'error',out.get('error',''),flush=True)
    return out
def math_close(a,b):return abs(a-b)<=1e-10*max(abs(b),1.)
def production_check_live(book):
    from verify_source import canonical
    original=macros(SOURCE)
    actual={c.Name:(c.CodeModule.Lines(1,c.CodeModule.CountOfLines) if c.CodeModule.CountOfLines else '') for c in book.VBProject.VBComponents}
    assert len(actual)==len(original)+1
    for filename,text in original.items():
        name=filename.rsplit('.',1)[0];assert canonical(text)==canonical(actual[name]),name
    return {'pass':True,'original_modules_unchanged':len(original),'only_added_module':'BatchEvidence'}
def progress():
    rows=[]
    for case in ORDER:
        path=ROOT/'cases'/case/'status.json'
        rows.append(json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'case':case,'status':'NOT_RUN'})
    path=ROOT/'results/progress.csv';temp=path.with_suffix('.tmp')
    columns=['case','status','analysis_seconds','lower_fs','upper_fs','fs_obtained','target_met','error']
    with temp.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(columns)
        for row in rows:w.writerow([row.get(k,'') for k in columns])
    temp.replace(path)
    write(ROOT/'results/batch_summary.json',{'updated_utc':utc(),'count':26,'all_cases_executed':all(r['status'] not in ['NOT_RUN','PREPARING','RUNNING'] for r in rows),
        'fs_obtained':sum(r.get('fs_obtained',False) for r in rows),'target_met':sum(r.get('target_met',False) for r in rows),'results':rows})
    return rows
def batch():
    assert TEMPLATE.exists()
    for case in ORDER:
        if (ROOT/'STOP').exists():
            write(ROOT/'results/user_interruption.json',{'utc':utc(),'source':'STOP marker; cooperative RPX_Stop, no forced process termination'})
            progress();return
        existing=ROOT/'cases'/case/'status.json'
        if existing.exists():
            data=json.loads(existing.read_text(encoding='utf-8'))
            assert data['status'] not in ['RUNNING','PREPARING'],'Existing unfinished run requires review'
            continue
        proc=subprocess.Popen([sys.executable,'-X','utf8',str(Path(__file__).resolve()),'case',case],cwd=REPO)
        while proc.poll() is None:
            progress();time.sleep(5)
        progress()
        if proc.returncode!=0:write(ROOT/'results'/f'{case}_worker_error.json',{'case':case,'exit_code':proc.returncode})
    result=progress();assert all(r['status']!='NOT_RUN' for r in result)
    assert sha(SOURCE)==SOURCE_SHA and sha(DLL)==DLL_SHA
    print('ALL26_FINISHED',flush=True)
if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare_template()
    elif sys.argv[1]=='smoke':
        result=worker('D08A',True);assert result['fs_obtained'] and result['status'] in ['PASS_TARGET','FS_AVAILABLE_PARTIAL'],result
    elif sys.argv[1]=='case':worker(sys.argv[2])
    elif sys.argv[1]=='batch':batch()
