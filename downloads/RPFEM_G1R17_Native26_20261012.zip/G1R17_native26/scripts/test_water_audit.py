import numpy as np
from types import SimpleNamespace
from prepare import ROOT,write
from audit_case import expected_body
def model(xy):
    return SimpleNamespace(xy=np.array(xy,float),tri=np.array([[0,1,2]]),
        body=np.zeros((1,2,2)),materials=np.array([[10.,25.,25.,20.]]),material_id=np.array([0]))
wet={'coupling':1,'gamma_w':9.81}
dry={'coupling':0,'gamma_w':9.81}
assert np.array_equal(expected_body(model([(0,0),(2,0),(0,2)]),dry),np.array([[[0.,0.],[0.,-20.]]]))
assert np.allclose(expected_body(model([(0,0),(2,0),(0,2)]),wet),np.array([[[0.,0.],[0.,-10.19]]]),atol=1e-14,rtol=0)
assert np.allclose(expected_body(model([(0,4),(2,4),(0,6)]),wet),np.array([[[0.,0.],[0.,-20.]]]),atol=1e-14,rtol=0)
assert np.allclose(expected_body(model([(0,0),(2,0),(0,4)]),wet),np.array([[[0.,0.],[0.,-12.6425]]]),atol=1e-14,rtol=0)
write(ROOT/'results/python_water_audit_tests.json',{'pass':True,'cases':['dry','fully_submerged','above_water','P1 triangle crossing y=3'],
    'scope':'Independent force-gradient audit preparation, not timing/Excel solver result'})
print('PASS Python independent water-gradient audit: dry/wet/above/straddling')
