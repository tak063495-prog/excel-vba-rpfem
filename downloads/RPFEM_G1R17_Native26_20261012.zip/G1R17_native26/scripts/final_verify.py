"""Verify completion and preserved evidence without repeating numerical solves."""
import csv, json, math
from prepare import ROOT, REPO, SOURCE, DLL, SOURCE_SHA, DLL_SHA, ORDER, sha, write
from report import rows

def verify():
    records=rows()
    assert len(records)==len(set(ORDER))==26
    assert sha(SOURCE)==SOURCE_SHA and sha(DLL)==DLL_SHA
    assert sha(ROOT/'workbooks/rpfem_native_x64.dll')==DLL_SHA
    protected=json.loads((ROOT/'results/published_package_before.json').read_text(encoding='utf8'))
    assert all(sha(REPO/'versions/G1R17'/name)==h for name,h in protected.items())
    profiles={'TARGET':1536,'ADAPT':1,'CYCLES':3,'QUADRATURE':8,'FS_TOL':1e-4,'GAP':0.01,
              'ADAPT_REFINE_CAP':1000,'HSD_SOLVE_SECONDS':300,'C0_AUTO':0,'RAW_LOWER_AUDIT':1,
              'DIAGNOSTIC_MODE':1,'TEST_INJECTION':0,'SEISMIC_KH':0}
    evidence=[]
    for r in records:
        case=r['case'];folder=ROOT/'cases'/case
        assert r['status'] in {'PASS_TARGET','FS_AVAILABLE_PARTIAL'},(case,r['status'])
        assert not r['smoke'] and r['fs_obtained'] and r['independent_audit']['pass'],case
        assert r['error_number']==0 and r['dll_actually_used'] and r['production_source_check']['pass'],case
        assert r['source_sha256']==SOURCE_SHA and r['dll_sha256']==DLL_SHA,case
        assert r['input_sha256']==sha(ROOT/'inputs'/f'{case}.json'),case
        assert r['runner_sha256']==sha(ROOT/'scripts/runner.py'),case
        assert r['workbook_sha256']==sha(ROOT/r['workbook']),case
        assert all(r['actual_settings'][k]==v for k,v in profiles.items()),case
        assert r['actual_settings']['ANALYSIS_POLICY']==('DAVIS_EQUIVALENT' if case.endswith('N') else 'ASSOCIATED'),case
        assert r['pore_pressure']==r['water_on_at_finish']==(case=='D08A'),case
        with (folder/'analysis.tsv').open(encoding='utf16') as f:
            ends=[e for e in csv.DictReader(f,delimiter='\t') if e['event']=='run_end']
        assert len(ends)==1 and math.isclose(float(ends[0]['elapsed_s']),r['analysis_seconds'],abs_tol=1e-9,rel_tol=0),case
        audits=r['independent_audit']['results']
        assert {a['side'] for a in audits}=={'lower','upper'},case
        assert all(a['pass'] and a['endpoint_direction_pass'] and a['raw_lower_pass'] for a in audits),case
        assert all(a['independent_body_max_error']<=1e-9 for a in audits),case
        assert [a['metadata']['q'] for a in audits]==r['witness_q'],case
        evidence.append({'case':case,'status':r['status'],'native_seconds':r['analysis_seconds'],
                         'workbook_sha256':r['workbook_sha256'],
                         'witness_sha256':{s:sha(folder/f'witness_{s}.bin') for s in ['lower','upper']},
                         'quadrature':r['witness_q'],'dll_used':True,'production_preserved':True})
    result={'pass':True,'completed':26,'audited_fs':26,'target_met':sum(r['target_met'] for r in records),
            'protected_files_unchanged':len(protected),'runner_sha256':sha(ROOT/'scripts/runner.py'),
            'scope':'Recorded native timings, input/profile identity, numerical DLL calls, independent physical audit results and saved file hashes; no numerical solve repeated',
            'cases':evidence}
    write(ROOT/'results/final_verification.json',result)
    print('FINAL_EVIDENCE_VERIFICATION PASS',26,'cases;',len(protected),'published files unchanged')
    return result

if __name__=='__main__':verify()
