"""Keep read-only measurement summaries accessible on the user's Desktop."""
from pathlib import Path
import json, shutil, time, traceback
import win32api, win32con, win32process, pywintypes
from prepare import ROOT, REPO, write, sha
from report import generate, package

DEST=Path('C:/Users/link_/Desktop/RPFEM_G1R17_Native26_20261012')
DEST.mkdir(exist_ok=True)
pid=int((ROOT/'results/batch_pid.txt').read_text().strip())
handle=win32api.OpenProcess(win32con.PROCESS_QUERY_LIMITED_INFORMATION,False,pid)
last=None
try:
    while True:
        signatures=[(p.as_posix(),p.stat().st_mtime_ns) for p in (ROOT/'cases').glob('*/status.json')]
        signature=tuple(sorted(signatures))
        if signature!=last:
            summary=generate();last=signature
            for name in ['REPORT.md','RESULTS.csv','PHASE_TIMINGS.csv']:
                shutil.copyfile(ROOT/name,DEST/name)
            shutil.copyfile(ROOT/'results/interim_summary.json',DEST/'interim_summary.json')
        active=win32process.GetExitCodeProcess(handle)==259
        if not active:break
        time.sleep(10)
    if not (ROOT/'STOP').exists():
        summary=generate(True);package()
        for name in ['REPORT.md','RESULTS.csv','PHASE_TIMINGS.csv','MANIFEST.json','SHA256SUMS.txt']:
            shutil.copyfile(ROOT/name,DEST/name)
        shutil.copyfile(ROOT/'results/final_summary.json',DEST/'final_summary.json')
        archive=REPO/'RPFEM_G1R17_Native26_20261012.zip'
        shutil.copyfile(archive,DEST/archive.name)
        assert sha(archive)==sha(DEST/archive.name)
        write(ROOT/'results/desktop_delivery.json',{'pass':True,'directory':str(DEST),'zip_sha256':sha(archive),'zip_bytes':archive.stat().st_size})
        print('FINAL_DESKTOP_DELIVERY',DEST,flush=True)
except Exception:
    write(ROOT/'results/progress_publisher_error.json',{'error':traceback.format_exc()})
    raise
finally:
    win32api.CloseHandle(handle)
