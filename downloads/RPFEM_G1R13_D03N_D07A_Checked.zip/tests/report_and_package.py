"""Generate the Japanese terminal report and a checksum-verified ZIP from actual evidence."""
from pathlib import Path
import json,hashlib,zipfile,csv,sys,subprocess
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    cases=[read('native_retry/'+c+'/status.json') for c in ['D03N','D07A']]
    assert all(r.get('fs_obtained') for r in cases),cases
    assert read('results/portable_audit.json')['pass'] and read('results/delivery_native_integrity.json')['pass']
    assert read('work_controls/result.json')['pass']
    rows=[]
    for r in cases:
        rows.append(f"| {r['case']} | {r['lower_fs']:.12g} | {r['upper_fs']:.12g} | {r['relative_gap']:.6%} | {r['status']} | {r['solve_seconds']:.1f}秒 |")
    point=read('single_point/D03N/status.json');oracle=read('results/work_oracle.json')
    text='''# G1R13：D03N/D07Aの修復と実Excel検証

G1R12でFsを出せなかったD03N・D07Aに対してVBAを修正し、設定済みXLSMで実Excelの全探索・適応解析を実行した。下表はPythonのFsを転記した値ではなく、修正版VBAの保存結果である。保存した上下界場を独立に再監査した。

| ケース | 下界Fs | 上界Fs | 相対GAP | 精度区分 | 実解析時間 |
|---|---:|---:|---:|---|---:|
'''+ '\n'.join(rows)+'''

`FS_AVAILABLE_PARTIAL`は物理監査済みのFsを取得したが、所有者の根幅・探索完了またはGAP目標を満たしていない部分結果。`PASS_TARGET`はこれらの条件も満たした結果。部分結果を目標精度達成へ昇格しない。下界・上界の間を評価範囲として扱う。

D03NのGAPは7.861733%で、目標1%に未達。最終二分探索の根幅は下界0.000109100154、上界0.000063474198で、数値的には各FS_TOLの幅を満たした。ただし既存の`RPX_ActualRootBracket`は両端の状態がOPTIMALであることを要求する。今回のc=0問題では下界の安定端点を荷重倍率1に正規化した`LOAD_RECESSION_CERT`（UNBOUNDED）、上界の反対端点をINFEASIBLEで判定するため、保存場のroot_validフラグは両方False。これをTrueへ書き換えず、`ADAPT_GAP_TARGET_NOT_MET`と併せて部分結果を維持する。第65求解まで終了し、下界の荷重倍率は1、独立物理誤差は約3.66e−9以下。採用上界の50桁仕事誤差は6.63e−11で、通常Doubleの単純集計では誤差3.94e−7になる。精度不足の集計による不合格を隠さず、独立高精度監査を採用根拠とする。

D07AはGAP約0.9781%を満たす。一方、採用上界は値の良い`adapt_1_band`のq=4場で、上界の根幅0.00494910が最終許容幅約0.00012776より大きい。最終q=8の同一最終メッシュでは上界Fs=1.2919990844・根幅0.00010318、下界Fs=1.2651420915・根幅0.00010104まで求解したが、上界のbest-field採用規則は旧場の小さいFs=1.2775772046を保持した。そのため全体の未完了フラグを消していない。Fs未取得の旧エラーとは区別する。

入力・設定はG1R12の25ケース台帳の該当ケースと同じ。TARGET=1536、設定q=8、ADAPT=1、CYCLES=3、FS_TOL=1e-4、GAP=1%、C0_AUTO=0、TEST_INJECTION=0。採用された各場の実際のq・要素数・根幅/完了フラグは個別status.jsonおよびbinary snapshotを参照する。途中の粗探索や別メッシュの良い場を保存する既存の方式を維持しており、設定qと保存場qを混同しない。

D03Nはc=0、φ=45°、ψ=0°、γ=20のDavis等価モデル。直接の非関連流れ則モデルの解とは区別する。D07Aはc=10、φ=ψ=25°、γ=20、上載荷重20のケース。間隙水圧は今回の対象外。

## 修正内容

- D03N：強い相殺が起きる参照仕事をDD積和で評価する。純c=0・固定荷重0・全荷重reference・剛体なし・原目的と全円錐offsetが厳密に0の場合だけ、正の仕事で候補を限定正規化する。正規化後の元等式・円錐・全物理監査を同じ許容差で再評価し、x/field/slackを整合させ、定数ゼロ目的の零双対証明を用いる。一般のHSD最適性や混合cのP06へ無条件に流用しない。
- D03N：既知の正確なエラー5 `HSD_DD_PRODUCT_UNDERFLOW`はFs試行内だけUNKNOWNとして記録し、既存の限定近傍点試行へ進む。UNKNOWNの値や場でブラケット端点を動かさない。DD/LDLのunderflowガードは保持する。
- D07A：直線外周の荷重段差にある2三角形fanを検査し、荷重差と内部辺方向が不整合な場合だけ2親三角形を重心分割する。元の境界・荷重・材料・面積を維持する。粗メッシュは314→316節点、553→557要素。
- 新しいメッシュをraw荷重段階で確定し、Fsブラケットを無効化する。既存のモデル完全同一性、下界cache、P1再利用、cold-start、取消応答は保持する。

変更は既存4標準モジュールと新規2標準モジュール。既存42標準モジュール、9文書モジュール、1クラスのコードは維持。構成則・Davis変換・上下界定式化・荷重・LDL/NT/HSDの方向計算・各許容差を変更していない。ノルム最小化による場選択やunderflowガードの一律削除は実装していない。

## 検証の区分

| 区分 | 実施した確認 |
|---|---|
| 静的/原本保全 | 42標準モジュールの全文一致、数値核・許容差の維持、0945のbaseline/reference 32ファイルの実装前後SHA保全 |
| 先行Python | 以前の実装前診断にあるD07Aの局所整合性・修復、D03Nの高精度仕事と近傍点試験に基づく |
| 今回Python | 実VBAで保存した場の50桁物理監査、元候補の正確な有理数仕事、配布パッケージの独立再生 |
| Excelコンパイル | 修正版、対照試験、失敗注入、配布版をネイティブExcelで確認 |
| 実Excelの単点 | D03Nの実際の停止メッシュ997要素・548節点、Fs=1.2094374254289846、q=8で求解終了と物理監査を確認 |
| 実Excelの対照/失敗注入 | 仕事正規化15条件、荷重段差11条件、実際のTryFsValueの7失敗注入。取消・容量・添字・荷重段階・監査・未知エラーを停止/不採用へ正しく分類 |
| 実Excelのメッシュ回帰 | 25ケースの修正前後粗メッシュを構築。D07A以外24ケースは座標・結合・材料・荷重を含む完全モデル文字列が一致 |
| 保存場回帰 | D01A/D02A/P06A/P06N/P02A/P02Nの既存12場を独立50桁で再監査。今回の新規全解析とは区別 |
| 実Excelの全解析 | D03N/D07Aの標準設定の全探索・適応解析、およびその上下界場の独立再監査 |

メッシュ比較は`RPX_ExactModel`・`RPX_ExactDouble`を使い、Doubleの8バイトを16進文字列化して比較した。丸めた小数表示やハッシュ値だけを同一性の証拠にしていない。D03Nの新しい全解析は65求解で終了し、旧解析の59個すべてのsolve-start ID・stage・mode・Fs表示ラベルが同じ順序で一致した。これは探索ラベルの比較であり、中間場のビット単位同一性の主張ではない。

下界はlambda_maxの端点契約（lambda>=1−1e−8、物理監査1e−7）で評価する。固定単位荷重の監査関数が出すabs(lambda−1)を、lambda_max問題の違反へ誤って数えない。上界は物理仕事・流れ・辺全体の跳躍・境界条件・目的値とcollapse条件を確認する。50桁監査は保存したbinary64場の数値検算であり、連続体の厳密な実数区間証明ではない。

## D03Nの精度回復の証拠

元の棄却候補は最大速度約2.26e7、正負仕事の絶対量が約6e8。通常集計だけでなく、正確な座標・場の積分でも仕事誤差2.25e−7となり不合格だった。DD仕事で正規化した実VBA場は仕事誤差6.63e−11となり、他の物理監査も通過した。単点再求解は反復50で終了し、追加反復51のunderflowへ進まずに済んだ。

新しい全解析でも、元と同じ第59求解・Fs=1.2094374254289846を反復50で通過した。DD仕事W=0.99999977408946で正規化し、元の等式のDD残差3.69e−12、円錐違反0、ネイティブ仕事誤差1.11e−9、その他の全物理監査を通過して`ZERO_COST_FEASIBLE_POINT`としてcommitした。第59求解の実solve時間は388.8秒。記録は`results/old_stop_point_full_run.json`にある。旧停止点での候補場を無監査で採用した結果ではない。

単点の準備と原候補対照を含む時間は'''+f"{point['seconds']:.1f}"+'''秒。実際の単点solve_endは約394.5秒。元の中間Fsを15桁ログから再構成しているため、全探索のビット単位完全再現とは主張しない。修復した最終結果の根拠は新しい全解析と保存場監査である。

## 制限と速度

今回の主目的は両ケースで監査済みFsを得ること。高速化のため、先行Python・実メッシュの単点再求解・局所修復・候補監査へ精度処理を限定した。DDを全内側ループへ追加していない。新しいFs取得は以前の停止結果と比較するため、全解析の高速化率は算定しない。同じ入力・同じ終端条件の反復測定をしていない。

最初の並行全解析では複数ExcelプロセスとのRPC通信が同時に切れた。原因は未特定で、数値エラー停止の証拠はない。これらは合格に数えず、失敗ログを保存し、D07A/D03Nを順次再実行した。追加のD01A全解析も通信断で未完了であり、新規全解析PASSとは数えない。

25ケースすべてを今回のG1R13で再求解したわけではない。元のG1R12の台帳と今回の2ケース修復結果を区別する。過去のFAILEDやNOT_RUNの台帳を後からPASSへ書き換えていない。

## ファイルと再生

- `delivery/`：D03N・D07Aの設定済み修正版XLSM。実Excelの保存Fsあり。試験専用モジュールを除去後、再コンパイル・ソース・入力/設定・保存Fsを検査した。
- `src/vba/`：48標準モジュールのUTF-8編集用ソース。`import/`：実プロジェクトのCP932・CRLFに対して損失なし検査済みのインポート用ソース。
- `before/vba/`、`changes.diff`、`ISSUE_TO_FIX_JA.md`、`IMPORT_ROLLBACK_JA.md`：変更前、統合差分、対応表、導入/復旧手順。
- `native_retry/`：実Excelの最終結果・ログ・上下界binary場。`single_point/`：実メッシュ単点・原候補対照。`controls/`、`fs_controls/`、`mesh25_retry/`：対照・注入・回帰の記録。
- `results/portable_audit.json`と`tests/verify_portable.py`：同梱ランタイムだけを用いる物理再監査。Python環境へrequirements.txtを導入し、パッケージ直下で`python -X utf8 tests/verify_portable.py`を実行する。
- `MANIFEST.json`：ZIP内各ファイルのSHA-256。ZIPを実際に読み戻して検証した。

0945の歴史的P2-Sパッケージは変更していない。今回の対象をその原版へ置換せず、継続中のG1R12を別名コピーで修復した。GitHubへの公開、マクロセキュリティやレジストリの変更は行っていない。
'''
    (ROOT/'G1R13_D03N_D07A_Repair_Report_JA.md').write_text(text,encoding='utf-8')
    ledger=[['test','kind','status','evidence'],['source_preservation','STATIC','PASS','results/source_regression.json'],['work_oracle','PYTHON','PASS','results/work_oracle.json'],['load_step_11_controls','EXCEL_EXECUTION','PASS','controls/load_step_results.json'],['fs_7_failures','EXCEL_EXECUTION','PASS','fs_controls/result.json'],['coarse_mesh_25','EXCEL_MESH_ONLY','PASS','mesh25_retry/result.json'],['reference_12_fields','PYTHON_REAUDIT','PASS','results/reference_fields.json'],['D03N_single_point','EXCEL_EXECUTION','PASS','single_point/D03N/status.json']]
    ledger += [[r['case']+'_full','EXCEL_EXECUTION',r['status'],'native_retry/'+r['case']+'/status.json'] for r in cases]
    ledger += [['work_normalization_15_controls','EXCEL_EXECUTION','PASS','work_controls/result.json'],['D01A_full_attempt','EXCEL_EXECUTION','INTERRUPTED_RPC','cases/D01A/status.json'],['25_full_G1R13','EXCEL_EXECUTION','NOT_RUN','Only 2 repaired cases rerun fully'],['delivery_compile_encoding','EXCEL_COMPILE','PASS','results/delivery_native_integrity.json']]
    with (ROOT/'results/test_ledger.csv').open('w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerows(ledger)
    paths=[]
    for directory in ['src','import','before','tests','results','evidence','validation_runtime','inputs','delivery','controls','fs_controls','work_controls','mesh25_retry','native_retry','single_point']:
        for p in (ROOT/directory).rglob('*'):
            if p.is_file() and p.suffix not in ['.xlsm','.tmp','.pyc','.zip'] and '__pycache__' not in p.parts:paths.append(p)
    paths += list((ROOT/'delivery').glob('*.xlsm'))
    for case in ['D03N','D07A','D01A']:
        folder=ROOT/'cases'/case
        paths += [p for p in folder.rglob('*') if p.is_file() and p.suffix in ['.json','.tsv','.txt']]
    paths += [ROOT/n for n in ['G1R13_D03N_D07A_Repair_Report_JA.md','IMPORT_ROLLBACK_JA.md','ISSUE_TO_FIX_JA.md','changes.diff','requirements.txt']]
    paths=sorted(set(paths));manifest={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in paths}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    package=ROOT/'delivery/RPFEM_G1R13_D03N_D07A_Checked.zip';assert not package.exists()
    with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in paths+[ROOT/'MANIFEST.json']:z.write(p,str(p.relative_to(ROOT)).replace('\\','/'))
    with zipfile.ZipFile(package) as z:
        assert z.testzip() is None
        for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h,name
    rec={'zip':str(package),'sha256':sha(package),'members':len(manifest)+1,'all_members_verified':True,'bytes':package.stat().st_size}
    (ROOT/'delivery/ZIP_VERIFIED.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(rec,ensure_ascii=False))
if __name__=='__main__':main()
